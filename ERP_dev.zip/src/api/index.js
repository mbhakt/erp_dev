// src/api/index.js
// Simple fetch-based API client used by the frontend.
// Designed to be a drop-in replacement that exports the common CRUD functions
// used across the app (parties, items, purchases, expenses, invoices).

const API_BASE = (import.meta.env?.VITE_API_BASE) || "/api";

/** Helper: build query string from params object */
function qs(params = {}) {
  const keys = Object.keys(params || {});
  if (!keys.length) return "";
  const parts = keys
    .filter((k) => params[k] !== undefined && params[k] !== null && params[k] !== "")
    .map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(String(params[k]))}`);
  return `?${parts.join("&")}`;
}

/** Helper to handle JSON/non-JSON responses and HTTP errors */
async function handleRes(res) {
  const text = await res.text();
  let data;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = text;
  }

  if (!res.ok) {
    const err = new Error((data && data.message) || res.statusText || "API error");
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}

/** Generic request wrapper */
async function request(url, opts = {}) {
  const res = await fetch(url, opts);
  return handleRes(res);
}

/* -------------------------
   Parties
   ------------------------- */
export async function fetchParties(params) {
  return request(`${API_BASE}/parties${qs(params)}`);
}
export async function fetchParty(id) {
  return request(`${API_BASE}/parties/${id}`);
}
export async function createParty(payload) {
  return request(`${API_BASE}/parties`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}
export async function updateParty(id, payload) {
  return request(`${API_BASE}/parties/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}
export async function deleteParty(id) {
  return request(`${API_BASE}/parties/${id}`, { method: "DELETE" });
}

/* -------------------------
   Items
   ------------------------- */
export async function fetchItems(params) {
  return request(`${API_BASE}/items${qs(params)}`);
}
export async function fetchItem(id) {
  return request(`${API_BASE}/items/${id}`);
}
export async function createItem(payload) {
  return request(`${API_BASE}/items`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}
export async function updateItem(id, payload) {
  return request(`${API_BASE}/items/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}
export async function deleteItem(id) {
  return request(`${API_BASE}/items/${id}`, { method: "DELETE" });
}

/* -------------------------
   Purchases (Purchase Bills)
   ------------------------- */
export async function fetchPurchases(params) {
  return request(`${API_BASE}/purchases${qs(params)}`);
}
export async function fetchPurchase(id) {
  return request(`${API_BASE}/purchases/${id}`);
}
export async function createPurchase(payload) {
  return request(`${API_BASE}/purchases`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}
export async function updatePurchase(id, payload) {
  return request(`${API_BASE}/purchases/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}
export async function deletePurchase(id) {
  return request(`${API_BASE}/purchases/${id}`, { method: "DELETE" });
}

/* -------------------------
   Expenses
   ------------------------- */
export async function fetchExpenses(params) {
  return request(`${API_BASE}/expenses${qs(params)}`);
}
export async function fetchExpense(id) {
  return request(`${API_BASE}/expenses/${id}`);
}
export async function createExpense(payload) {
  return request(`${API_BASE}/expenses`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}
export async function updateExpense(id, payload) {
  return request(`${API_BASE}/expenses/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}
export async function deleteExpense(id) {
  return request(`${API_BASE}/expenses/${id}`, { method: "DELETE" });
}

/* -------------------------
   Invoices
   ------------------------- */
export async function fetchInvoices(params) {
  return request(`${API_BASE}/invoices${qs(params)}`);
}
export async function fetchInvoice(id) {
  return request(`${API_BASE}/invoices/${id}`);
}
export async function createInvoice(payload) {
  return request(`${API_BASE}/invoices`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}
export async function updateInvoice(id, payload) {
  return request(`${API_BASE}/invoices/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}
export async function deleteInvoice(id) {
  return request(`${API_BASE}/invoices/${id}`, { method: "DELETE" });
}

/* -------------------------
   Misc / exports
   ------------------------- */
export default {
  // parties
  fetchParties,
  fetchParty,
  createParty,
  updateParty,
  deleteParty,

  // items
  fetchItems,
  fetchItem,
  createItem,
  updateItem,
  deleteItem,

  // purchases
  fetchPurchases,
  fetchPurchase,
  createPurchase,
  updatePurchase,
  deletePurchase,

  // expenses
  fetchExpenses,
  fetchExpense,
  createExpense,
  updateExpense,
  deleteExpense,

  // invoices
  fetchInvoices,
  fetchInvoice,
  createInvoice,
  updateInvoice,
  deleteInvoice,
};


// ---------------------------------------------------------------------
// Backwards-compatibility aliases (legacy names used throughout app)
// Some modules still import e.g. `getExpenses`, `getInvoices`, etc.
// Map them to the new fetch* functions so both styles work.
// ---------------------------------------------------------------------
export const getParties = fetchParties;
export const getParty = fetchParty;
export const addParty = createParty;
export const editParty = updateParty;
export const removeParty = deleteParty;

export const getItems = fetchItems;
export const getItem = fetchItem;
export const addItem = createItem;
export const editItem = updateItem;
export const removeItem = deleteItem;

export const getPurchases = fetchPurchases;
export const getPurchase = fetchPurchase;
export const addPurchase = createPurchase;
export const editPurchase = updatePurchase;
export const removePurchase = deletePurchase;

export const getExpenses = fetchExpenses;
export const getExpense = fetchExpense;
export const addExpense = createExpense;
export const editExpense = updateExpense;
export const removeExpense = deleteExpense;

export const getInvoices = fetchInvoices;
export const getInvoiceById = fetchInvoice;
export const createInvoiceLegacy = createInvoice;
export const updateInvoiceLegacy = updateInvoice;
export const deleteInvoiceLegacy = deleteInvoice;