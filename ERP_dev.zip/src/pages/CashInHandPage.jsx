import React from "react";
import AppLayout from "../components/AppLayout";
import { Card } from "antd";
export default function CashInHandPage(){ return <AppLayout><h2>Cash in Hand</h2><Card><div className="card-empty">Cash management placeholder (add transactions UI here)</div></Card></AppLayout>; }