const icons = {
  'home.svg': '/assets/icons/home.svg',
  'parties.svg': '/assets/icons/parties.svg',
  'items.svg': '/assets/icons/items.svg',
  'sale.svg': '/assets/icons/sale.svg',
  'bank.svg': '/assets/icons/bank.svg',
  'reports.svg': '/assets/icons/reports.svg',
  'settings.svg': '/assets/icons/settings.svg',
  'sync.svg': '/assets/icons/sync.svg',
  'utilities.svg': '/assets/icons/utilities.svg',
  'plans.svg': '/assets/icons/plans.svg'
}
export default icons
