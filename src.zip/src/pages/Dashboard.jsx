import React, { useEffect, useState } from 'react';
import { Row, Col, Card } from 'antd';
import { fetchDashboard } from '../api/mockApi';
import { currencyINR } from '../utils/format';
import { LineChart, Line, ResponsiveContainer } from 'recharts';
import { fetchReports } from '../api/mockApi';
import AppLayout from '../components/AppLayout';

export default function Dashboard(){
  const [summary, setSummary] = useState({});
  const [chartData, setChartData] = useState([]);
  useEffect(()=>{ fetchDashboard().then(setSummary); fetchReports().then(r=>setChartData(r.sales||[])); },[]);
  return (
    <AppLayout>
      <div>
        <h2>Dashboard</h2>
        <Row gutter={16}>
          <Col span={8}><Card><h4>Total Receivable</h4><div style={{fontSize:22}}>{currencyINR(summary.totalReceivable)}</div></Card></Col>
          <Col span={8}><Card><h4>Total Payable</h4><div style={{fontSize:22}}>{currencyINR(summary.totalPayable)}</div></Card></Col>
          <Col span={8}><Card><h4>Total Sale</h4><div style={{fontSize:22}}>{currencyINR(summary.totalSale)}</div></Card></Col>
        </Row>
        <Card style={{ marginTop:20 }} title="Total Sale">
          <div style={{ height:220 }}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <Line type="monotone" dataKey="value" stroke="#2a9df4" strokeWidth={3} dot={{r:4}}/>
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>
    </AppLayout>
  );
}
