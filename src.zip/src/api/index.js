// Auto-generated aggregator index — re-exports API functions and provides fetch* aliases for get* names

export { addExpense, addItem, addParty, addPurchase, createExpense, createInvoice, createInvoiceLegacy, createItem, createParty, createPurchase, deleteExpense, deleteInvoice, deleteInvoiceLegacy, deleteItem, deleteParty, deletePurchase, editExpense, editItem, editParty, editPurchase, fetchExpense, fetchExpenses, fetchInvoice, fetchInvoices, fetchItem, fetchItems, fetchParties, fetchParty, fetchPurchase, fetchPurchases, fetchExpense, fetchExpenses, fetchInvoiceById, fetchInvoices, fetchItem, fetchItems, fetchParties, fetchParty, fetchPurchase, fetchPurchases, removeExpense, removeItem, removeParty, removePurchase, updateExpense, updateInvoice, updateInvoiceLegacy, updateItem, updateParty, updatePurchase } from './index';
export { fetchItems, fetchParties, fetchBanks, fetchDashboard, fetchInvoices, fetchPartyTransactions, fetchPurchases, fetchReports } from './mockApi';

// fetch* aliases for get* exports
export { fetchExpense as fetchExpense } from './index';
export { fetchExpenses as fetchExpenses } from './index';
export { fetchInvoiceById as fetchInvoiceById } from './index';
export { fetchInvoices as fetchInvoices } from './index';
export { fetchItem as fetchItem } from './index';
export { fetchItems as fetchItems } from './index';
export { fetchParties as fetchParties } from './index';
export { fetchParty as fetchParty } from './index';
export { fetchPurchase as fetchPurchase } from './index';
export { fetchPurchases as fetchPurchases } from './index';
export { fetchBanks as fetchBanks } from './mockApi';
export { fetchDashboard as fetchDashboard } from './mockApi';
export { fetchInvoices as fetchInvoices } from './mockApi';
export { fetchPartyTransactions as fetchPartyTransactions } from './mockApi';
export { fetchPurchases as fetchPurchases } from './mockApi';
export { fetchReports as fetchReports } from './mockApi';
